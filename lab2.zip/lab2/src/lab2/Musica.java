/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2;

public class Musica {
    private String singer;
    private String genre;
    private String title;
    
    
    public String getsinger() {
        return singer;
    }
    public void setsinger(String singer) {
        this.singer = singer;
    }
    public String getgenre() {
        return genre;
    }
    public void setgenre(String genre) {
        this.genre = genre;
    }
    
    public String gettitle() {
        return title;
    }
    public void settitle(String role) {
        this.title = title;
    }

    
    }
    
    
    
    

