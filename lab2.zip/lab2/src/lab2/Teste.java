/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2;

/**
 *
 * @author Vanda
 */
import java.io.File;

public class Teste {

    /**
     * @param args the command line arguments
     * @throws java.lang.Exception
     */
    public static void main(String[] args) throws Exception {

Validador validador = new Validador();
		validador.valida(new File("Musica.xml"), new File("Musica.xsd"));
        
    }
    
}
